# PG del Campo — Panel (versión web)

Versión limpia del panel **PG del Campo** lista para publicarse con **GitHub Pages**.
Es una página autocontenida: todo el código está en `index.html` y las librerías
se cargan desde CDN, por lo que no necesita instalación ni servidor propio.

## Cómo publicarla en GitHub Pages

1. Crea un repositorio en GitHub (por ejemplo `pg-del-campo`).
2. Sube a la **raíz** del repositorio estos archivos:
   - `index.html`
   - `.nojekyll` (evita que GitHub procese la página con Jekyll)
   - `README.md` (opcional)
3. En GitHub ve a **Settings → Pages**.
4. En **Source** elige la rama (por ejemplo `main`) y la carpeta `/root`.
5. Guarda. En unos minutos tu panel estará disponible en:
   `https://<tu-usuario>.github.io/<nombre-del-repo>/`

## Acceso de demostración

- Usuario: `admin`
- Clave: `1234`

> ⚠️ **Cambia estas credenciales antes de publicar.** Si el repositorio es
> público, cualquiera podría verlas en el código.

## Nota sobre Firebase

El panel puede conectarse a Firebase para sincronización en vivo. Si tu
configuración (claves) está dentro del HTML y el repositorio es público, esa
configuración quedará visible. Antes de publicar:

- Activa **reglas de seguridad** en tu base de datos de Firebase.
- Restringe la **clave de API** por dominio (Firebase Console → Configuración).

Sin conexión a Firebase, el panel funciona igual de forma local en el navegador.
